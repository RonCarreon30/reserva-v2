<footer class="bg-white shadow-lg">
    <div class="container mx-auto px-6 py-1">
        <p class="text-gray-600 text-center">&copy; Reserva.</p>
    </div>
</footer>